import json
from routine_driver_normalizer import Normalizer

def read_config():
    with open("config.json") as data_file:
        config_data = json.load(data_file)
    return config_data

n = Normalizer(read_config())
n.run()
