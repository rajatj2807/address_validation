from pyspark import SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_date, col, to_timestamp, unix_timestamp, to_date, udf
from pyspark.sql.functions import when, expr
from itertools import chain
from pyspark.sql.functions import create_map, lit
from pyspark.sql.window import Window as W
from pyspark.sql import functions as F
from pyspark.sql import SQLContext
from pyspark.sql.functions import broadcast

import us

from AddressUtil import validate_usps

class Normalizer:
    def __init__(self, config_data):
        self.spark = None
        self.input_path = config_data['input_path']
        self.s3_input_path=config_data['s3_input_path']
        self.output_path = config_data['output_path']
        self.mapping_json = config_data['mapping_json']
        self.partition_column = config_data['partition_column']
        self.usps_id = config_data['usps_id']
        self.common_final_lst = []
        self.json_excluded_lst = []
        self.csv_final_list = []
        self.csv_excluded_list = []
        self.source_data = None
        self.final_data = None
        self.spk_context = None
        self.sqlContext = None
        self.s3_df = None
        self.not_validated = None

    def run(self):
        self.create_connection()
        self.source_data = self.spark.read.csv(self.input_path, header=True)

        #reading all the header names from the source csv file
        lst_csv = self.source_data.schema.names
        lst_json = list(self.mapping_json.keys())

        self.check_conf_header_extra_col(lst_csv, lst_json)

        #self.address_transformation(self.usps_id)



        self.column_alising()

        self.date_transformation()

        self.gender_transformation()

        self.telephonenumber_transformation()

        self.final_data.show()

        self.validate_from_s3()

        self.write_data_file()


    def create_connection(self):
        self.spark = SparkSession.builder.appName("my_app").config('spark.sql.codegen.wholeStage', False).getOrCreate()
        self.spk_context = self.spark.sparkContext
        self.sqlContext = SQLContext(self.spk_context)
        access_key="AKIAVIBWLSSISZ4ZW45L"
        secret_key="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"
        self.spark.conf.set("fs.s3n.awsAccessKeyId", access_key)
        self.spark.conf.set("fs.s3n.awsSecretAccessKey", secret_key)
        self.spark.conf.set("fs.s3n.impl", "org.apache.hadoop.fs.s3native.NativeS3FileSystem")
        self.spark.conf.set("fs.s3n.endpoint", "us-east-1")



    def check_conf_header_extra_col(self, lst_csv, lst_json):
        # for checking if column is not present in the csv file and present in the json
        for i in lst_json:
            if i in lst_csv:
                self.common_final_lst.append(i)

        # column present in csv but not present in the json
        for i in lst_csv:
            if i not in lst_json:
                self.csv_final_list.append(i)


    def validate_from_s3(self):
        #reading from s3
        self.s3_df = self.spark.read.parquet(self.s3_input_path)

        #creating state abbreviation list
        state_abbr_list = self.source_data.select("addr_state").distinct().rdd.map(lambda x:str(x[0])).collect()

        #creating address set from s3
        final_s3_data = self.s3_df[["full_address","address_line_2","city","zip","state"]]

        #filtering state
        s3_data=final_s3_data.filter(col('state').isin(state_abbr_list) == True)

        def addr_Abr(data):
            try:
                state = us.states.lookup(data["ADDRESS_STATE"])
                data["ADDRESS_STATE"] = state.abbr
                return data
            except:
                return data

        state_rdd = self.final_data.rdd.map(lambda x: addr_Abr(x.asDict()))

        self.final_data = self.sqlContext.createDataFrame(state_rdd, self.final_data.schema)

        validated = broadcast(self.final_data.join(s3_data, (self.final_data.ADDRESS_LINE_1 == s3_data.full_address)
                             & (self.final_data.ADDRESS_CITY == s3_data.city)
                             & (self.final_data.ADDRESS_STATE == s3_data.state)
                             & (self.final_data.ADDRESS_POSTAL_CODE == s3_data.zip)
                            ).drop(s3_data.full_address).drop(s3_data.city).drop(s3_data.state).drop(s3_data.zip).drop(s3_data.address_line_2))


        self.not_validated = self.final_data.subtract(validated)



        self.not_validated = self.not_validated.withColumn("Validation",lit("False"))

        validated = validated.withColumn("Validation",lit("True"))

        print('validated')
        #validated.show()

        print('self.not_validated')
        #self.not_validated.show()

        self.address_transformation(self.usps_id)

        #self.not_validated.show()


        self.final_data = validated.union(self.not_validated)




    def address_transformation(self, usps_id):
        usps_validate = self.not_validated.rdd.map(lambda row:validate_usps(row.asDict(), usps_id, []))
        self.not_validated = self.sqlContext.createDataFrame(usps_validate, self.not_validated.schema)
        del usps_validate


    def column_alising(self):
        # list of alis name
        columns = [col(c).alias(self.mapping_json[c]['name']) for c in self.common_final_lst]

        # extra col
        columns.extend([col(c) for c in self.csv_final_list])
        # all col mapping with extra
        self.final_data = self.source_data.select(columns)


    def date_transformation(self):
        for c in self.common_final_lst:
            if self.mapping_json[c]['type'].lower() == 'timestamp':
                target_column=self.mapping_json[c]["name"]
                self.final_data = self.final_data.withColumn(target_column, to_timestamp(col(target_column), "MM/dd/yyyy").cast("string"))


    def gender_transformation(self):
        #applying transformation on gender
        for i in self.mapping_json:
            if "mapping_data" in self.mapping_json[i]:
                if i in self.source_data.schema.names:
                    col_map = self.mapping_json[i]["mapping_data"]

                    col_name= self.mapping_json[i]["name"]

                    mapping_expr = create_map([lit(x) for x in chain(*col_map.items())])


                    self.final_data = self.final_data.withColumn(col_name, mapping_expr[self.final_data[col_name]])



    def telephonenumber_transformation(self):
        #Telephone number tranformation
        for i in self.mapping_json:
            if "bad_charcters" in self.mapping_json[i]:
                if i in self.source_data.schema.names:
                    bad_charc = self.mapping_json[i]["bad_charcters"]
                    col_name = self.mapping_json[i]["name"]
                    str_expr = '\\'.join(bad_charc)
                    reg_expr = "[" + str_expr + "]"
                    self.final_data = self.final_data.withColumn(col_name, F.regexp_replace(F.col(col_name), reg_expr, "").alias(col_name))


    def write_data_file(self):
        self.final_data.write.partitionBy(self.partition_column).format("parquet").mode("append").save(self.output_path)

        #self.final_data.coalesce(1).write.parquet(self.output_path, mode="overwrite")
