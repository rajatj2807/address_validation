import usps

def validate_usps(address, usps_id, s3_header):
    #valid_addr = dict()
    address['Validation'] = False
    try:
        # Formats the address to USPS parameters
        address_for_usps = usps.Address(
            name='',
            address_1=address['ADDRESS_LINE_1'],
            city=address['ADDRESS_CITY'],
            state=address['ADDRESS_STATE'],
            zipcode=address['ADDRESS_POSTAL_CODE']
        )
        usps_client = usps.USPSApi(usps_id)
        validation = usps_client.validate_address(address_for_usps)
        if 'Error' in validation.result['AddressValidateResponse']['Address']:
            pass
        else:
            address['Validation'] = True
            #usps_addr = validation.result['AddressValidateResponse']['Address']
            #print(usps_addr)
            #if 'ReturnText' not in usps_addr:
            #    valid_addr['full_address'] = address['ADDRESS_LINE_1']
            #    valid_addr['city'] = address['ADDRESS_CITY']
            #    valid_addr['state'] = address['ADDRESS_STATE']
            #    valid_addr['zip'] = address['ADDRESS_POSTAL_CODE']

    except Exception:
        pass
    return address
